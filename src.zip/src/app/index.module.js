(function() {
  'use strict';

  angular
    .module('findoo', ['ngAnimate', 'ngCookies', 'ngTouch', 'ngSanitize', 'ui.router', 'ui.bootstrap', 'toastr']);

})();
