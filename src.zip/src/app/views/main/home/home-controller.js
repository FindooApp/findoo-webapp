angular.module('findoo').controller('HomeController',
  /** ngInject */
  function ($scope){
  	$scope.showAdvanceSearch = false;
  })